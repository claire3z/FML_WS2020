import pickle
import random
from collections import namedtuple, deque
from typing import List

import numpy as np
np.set_printoptions(precision=1)

import settings
cols, rows = settings.COLS-2, settings.ROWS-2 # inner tiles

import events as e
from .callbacks import state_to_features
ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT']  # lay no bombs
#ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']

# printing pretty matrices
# from https://gist.github.com/braingineer/d801735dac07ff3ac4d746e1f218ab75
def matprint(mat, fmt="g"):
    col_maxes = [max([len(("{:"+fmt+"}").format(x)) for x in col]) for col in mat.T]
    for x in mat:
        for i, y in enumerate(x):
            print(("{:"+str(col_maxes[i])+fmt+"}").format(y), end="  ")
        print("")

# This is only an example!
Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward'))

# Hyper parameters -- DO modify
TRANSITION_HISTORY_SIZE = 3  # keep only ... last transitions
RECORD_ENEMY_TRANSITIONS = 1.0  # record enemy transitions with probability ...

# Events
PLACEHOLDER_EVENT = "PLACEHOLDER"


def setup_training(self):
    """
    Initialise self for training purpose.

    This is called after `setup` in callbacks.py.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """
    # Example: Setup an array that will note transition tuples
    # (s, a, r, s')
    self.transitions = deque(maxlen=TRANSITION_HISTORY_SIZE)
    self.eventList = []
    self.rewardList = []
    self.gamma = 0.5
    print('start')
    
    # initialize Q(s,a)
    #self.Q = np.random.rand((cols*rows)**2+1, 5) # purely random (agnostic) initialisation)
    numberStates = (2*cols-1)*(2*rows-1)+1 # xdist, ydist, no coin
    self.Q = np.zeros((numberStates, 4)) # no WAIT, no BOMB
    for s in range(self.Q.shape[0]-1):
        cdx = s%(2*cols-1)-(cols-1)
        cdy = s//(2*cols-1)-(rows-1)
        dist = abs(cdx)+abs(cdy)
        self.Q[s,0] = -(1/(dist+1))*np.sign(cdy) #UP # alternative:np.exp(-dist/3)
        self.Q[s,1] = (1/(dist+1))*np.sign(cdx) #RIGHT # alternative:np.exp(-dist/3)
        self.Q[s,2] = -self.Q[s,0] #DOWN
        self.Q[s,3] = -self.Q[s,1] #LEFT
    #self.Q[:,-1] = -5 # never wait
    self.Q[-1,:] = 0 # no coin left (terminal state)
    self.Pi = np.argmax(self.Q, axis=1)
    #print(self.Q)
    print(self.Pi)
    self.currentRound = []
    return(self)
    
    '''
    # initialize Q(s,a)
    #self.Q = np.random.rand((cols*rows)**2+1, 5) # purely random (agnostic) initialisation)
    self.Q = np.zeros(((cols*rows)**2+1, 5))
    for s in range(self.Q.shape[0]-1): #checked: is inverse function of state definition
        cx = s//(cols*rows**2)
        cy = (s%(cols*rows**2))//(cols*rows)
        px = (s%(cols*rows))//rows
        py = s%rows
        dist = abs(cx-px)+abs(cy-py)
        #self.Q[s,:] = np.exp(-dist/3)
        self.Q[s,0] = np.exp(-dist/3)*np.sign(cy-py) #UP
        self.Q[s,1] = np.exp(-dist/3)*np.sign(cx-px) #RIGHT
        self.Q[s,2] = -self.Q[s,0] #DOWN
        self.Q[s,3] = -self.Q[s,1] #LEFT
    self.Q[:,-1] = -5 # never wait
    self.Q[-1,:] = 0 # no coin left (terminal state)
    
    self.Pi = np.argmax(self.Q, axis=1)
    
    print(self.Q[:,0])
    
    self.currentRound = []
    
    return(self)
    '''
    '''
    for tau in range(tauMax):
        for t in range(tauT):
            if np.random.rand() < eps:
                a[tau][t] = np.random.randint(6)
            else:
                a[tau][t] = np.argmax(Q[state,:])
    '''
    
    '''
    # s=0,1,2,3
    # a=0,1,2,3,4,5
    qzero = np.random.rand(4,6)
    qzero[-1,:] = 0 # terminal state
    piZero = np.argmax(qzero, axis=1)
    Q = [qzero]
    Pi = [piZero]
    '''


def game_events_occurred(self, old_game_state: dict, self_action: str, new_game_state: dict, events: List[str]):
    """
    Called once per step to allow intermediate rewards based on game events.

    When this method is called, self.events will contain a list of all game
    events relevant to your agent that occurred during the previous step. Consult
    settings.py to see what events are tracked. You can hand out rewards to your
    agent based on these events and your knowledge of the (new) game state.

    This is *one* of the places where you could update your agent.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    :param old_game_state: The state that was passed to the last call of `act`.
    :param self_action: The action that you took.
    :param new_game_state: The state the agent is in now.
    :param events: The events that occurred when going from  `old_game_state` to `new_game_state`
    """
    self.logger.debug(f'Encountered game event(s) {", ".join(map(repr, events))} in step {new_game_state["step"]}')

    #print(self.Q[:,0], )
    
    # store events
    #self.eventList.append(events)
    # rewards
    #reward = 0
    #if 'COIN_COLLECTED' in events:
    #    reward += 1
    #self.rewardList.append(reward)

    # Idea: Add your own events to hand out rewards
    #if ...:
    #    events.append(PLACEHOLDER_EVENT)

    # state_to_features is defined in callbacks.py
    self.transitions.append(Transition(state_to_features(old_game_state), self_action, state_to_features(new_game_state), reward_from_events(self, events)))
    #print(events)
    #print(reward_from_events(self, events))
    #print(state_to_features(new_game_state))
    
    if self_action is not None:
        #print('Old State: ', state_to_features(old_game_state))
        #print('Action: ', ACTIONS.index(self_action))
        #print('New State: ', state_to_features(new_game_state))
        #print('Reward: ', reward_from_events(self, events))
        new = np.array([state_to_features(old_game_state), state_to_features(new_game_state), ACTIONS.index(self_action), reward_from_events(self, events)])
        #print('new SAR: ', new)
        if len(self.currentRound) == 0:
            self.currentRound = new
        else:
            self.currentRound = np.row_stack((self.currentRound, new))
        #print('SAR: \n', self.currentRound)
        
    #return self

def end_of_round(self, last_game_state: dict, last_action: str, events: List[str]):
    """
    Called at the end of each game or when the agent died to hand out final rewards.

    This is similar to reward_update. self.events will contain all events that
    occurred during your agent's final step.

    This is *one* of the places where you could update your agent.
    This is also a good place to store an agent that you updated.

    :param self: The same object that is passed to all of your callbacks.
    """
    self.logger.debug(f'Encountered event(s) {", ".join(map(repr, events))} in final step')
    self.transitions.append(Transition(state_to_features(last_game_state), last_action, None, reward_from_events(self, events)))

    #print('FINAL STEP COMPLETED')
    #print('Old State: ', state_to_features(last_game_state))
    #print('Action: ', ACTIONS.index(last_action))
    #print('New State: ', state_to_features(last_game_state))
    #print('Reward: ', reward_from_events(self, events))
    new = np.array([state_to_features(last_game_state), state_to_features(last_game_state), ACTIONS.index(last_action), reward_from_events(self, events)])
    #print('final SAR: ', new)
    if len(self.currentRound) == 0:
        self.currentRound = new
    else:
        self.currentRound = np.row_stack((self.currentRound, new))
    #print('final SAR: \n', self.currentRound)
    
    SAR = self.currentRound.copy()
    alpha = 0.1 #0.6
    gamma = 0.5 #0.8
    
    #print('Q: ', self.Q)
    Qtest = np.zeros_like(self.Q)
    Qold = self.Q.copy()
    
    if np.ndim(SAR) == 1:
        SAR = [SAR]
    T = np.shape(SAR)[0]
    
    for t in range(T): # t=0,...,T_tau
        #print('SAR[t]: ', SAR[t])
        s,snext,a = SAR[t][:3].astype(int)
        r = SAR[t][3]
        #V = self.Q[snext,a] # SARSA
        #print(s,snext,a,r)
        #print(self.Q[snext,:])
        V = np.max(self.Q[snext,:]) # Q learning
        self.Q[s, a] = (1-alpha)*self.Q[s,a] + alpha*(r + gamma*V)
        Qtest[s,a] = 1
    
    #print('Qtest: ', Qtest)
    #print('Q new: ', self.Q)
    Qdiff = self.Q-Qold
    #print('Qdiff:', Qdiff[np.where(Qdiff!=0)])
    #print(np.mean(Qdiff[np.where(Qdiff!=0)]))
    
    self.currentRound = []

    '''
    # store events
    self.eventList.append(events)
    # rewards
    reward = 0
    if 'COIN_COLLECTED' in events:
        reward += 1
    if 'SURVIVED_ROUND' in events:
        reward += 10
    self.rewardList.append(reward)
    
    G = np.zeros(len(self.rewardList))
    Gsuc = 0
    for i in range(1, len(self.rewardList)+1):
        G[-i] = self.rewardList[-i] + self.gamma*Gsuc
        Gsuc = G[-i]
        
    RoundRewards = np.array((np.arange(len(G)), self.rewardList, G))
    '''
    #print('\n')
    #matprint(RoundRewards)

    self.Pi =  np.argmax(self.Q, axis=1)
    self.model = self.Pi.copy()
    #weights = self.Pi.copy()
    #weights = weights/sum(weights)
    #self.model = weights
    #print(str(self.model))

    # Store the model
    np.savetxt('my-saved-model.csv', self.model, delimiter=',')
    #np.savetxt(fname='my-saved-model.txt', X=self.model.astype(int))
    #result = np.loadtxt('data.csv', delimiter=',')
    #with open("my-saved-model.txt", "w") as file:
    #    file.write(str(self.model))
        #file.write('hello')
    #with open("my-saved-model.txt", "wb") as file:
    #    pickle.dump(self.model, file)


def reward_from_events(self, events: List[str]) -> int:
    """
    *This is not a required function, but an idea to structure your code.*

    Here you can modify the rewards your agent get so as to en/discourage
    certain behavior.
    """
    game_rewards = {
        e.COIN_COLLECTED: 1,
        e.KILLED_OPPONENT: 5,
        e.INVALID_ACTION: -1,
        e.KILLED_SELF: -5,
        e.SURVIVED_ROUND: 1 #5
        #PLACEHOLDER_EVENT: -.1  # idea: the custom event is bad
    }
    reward_sum = 0
    for event in events:
        if event in game_rewards:
            reward_sum += game_rewards[event]
    self.logger.info(f"Awarded {reward_sum} for events {', '.join(events)}")
    return reward_sum
